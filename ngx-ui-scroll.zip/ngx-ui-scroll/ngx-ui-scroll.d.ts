/**
 * Generated bundle index. Do not edit.
 */
export * from './public_api';
export { UiScrollComponent as ɵa } from './src/ui-scroll.component';
export { UiScrollDirective as ɵb } from './src/ui-scroll.directive';
