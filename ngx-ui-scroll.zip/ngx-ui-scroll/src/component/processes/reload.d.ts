import { Scroller } from '../scroller';
export default class Reload {
    static run(scroller: Scroller, reloadIndex: any): void;
}
