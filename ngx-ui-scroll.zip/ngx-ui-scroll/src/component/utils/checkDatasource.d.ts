import { Datasource as IDatasource } from '../interfaces/index';
export declare const checkDatasource: (datasource: IDatasource) => IDatasource;
