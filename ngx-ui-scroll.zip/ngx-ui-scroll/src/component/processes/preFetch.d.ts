import { Scroller } from '../scroller';
export default class PreFetch {
    static run(scroller: Scroller): void;
    static checkEOF(scroller: Scroller): boolean;
    static setStartIndex(scroller: Scroller): void;
    static processPreviousClip(scroller: Scroller): void;
}
