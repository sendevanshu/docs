import { Scroller } from '../scroller';
import { Item } from '../classes/item';
export default class PostRender {
    static run(scroller: Scroller): void;
    static processFetchedItems(items: Array<Item>): void;
    static runForward(scroller: Scroller, size: number): void;
    static runBackward(scroller: Scroller, size: number): number | null;
}
