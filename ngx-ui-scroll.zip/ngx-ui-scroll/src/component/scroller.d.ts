import { Observable, Subscription } from 'rxjs';
import { UiScrollComponent } from '../ui-scroll.component';
import { Datasource } from './classes/datasource';
import { Settings } from './classes/settings';
import { Routines } from './classes/domRoutines';
import { Viewport } from './classes/viewport';
import { Buffer } from './classes/buffer';
import { State } from './classes/state';
export declare class Scroller {
    readonly _bindData: Function;
    readonly callWorkflow: Function;
    private logs;
    version: string;
    datasource: Datasource;
    settings: Settings;
    routines: Routines;
    viewport: Viewport;
    buffer: Buffer;
    state: State;
    cycleSubscriptions: Array<Subscription>;
    constructor(context: UiScrollComponent, callWorkflow: Function);
    bindData(): Observable<any>;
    purgeCycleSubscriptions(): void;
    dispose(): void;
    finalize(): void;
    stat(str?: string): void;
    log(...args: Array<any>): void;
    logForce(...args: Array<any>): void;
}
