import { Scroller } from '../scroller';
import { Run } from '../interfaces/index';
export default class Start {
    static run(scroller: Scroller, options?: Run): void;
}
