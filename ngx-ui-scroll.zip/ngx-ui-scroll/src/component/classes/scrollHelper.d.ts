import { Workflow } from '../workflow';
export declare class ScrollHelper {
    readonly workflow: Workflow;
    private lastScrollTime;
    private scrollTimer;
    private lastScrollPosition;
    private endSubscription;
    constructor(workflow: Workflow);
    run(): void;
    throttledScroll(): void;
    purgeProcesses(): void;
    processScroll(): void;
}
