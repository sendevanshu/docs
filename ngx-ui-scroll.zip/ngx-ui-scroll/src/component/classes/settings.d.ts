import { Settings as ISettings, DevSettings as IDevSettings } from '../interfaces/index';
export declare const defaultSettings: ISettings;
export declare const minSettings: ISettings;
export declare const defaultDevSettings: IDevSettings;
export declare class Settings implements ISettings {
    adapter: boolean;
    startIndex: number;
    bufferSize: number;
    padding: number;
    infinite: boolean;
    horizontal: boolean;
    windowViewport: boolean;
    debug: boolean;
    immediateLog: boolean;
    clipAfterFetchOnly: boolean;
    clipAfterScrollOnly: boolean;
    paddingForwardSize: number;
    paddingBackwardSize: number;
    throttle: number;
    currentStartIndex: number;
    instanceIndex: number;
    constructor(settings: ISettings | undefined, devSettings: IDevSettings | undefined, instanceIndex: number);
    setCurrentStartIndex(startIndex: any): void;
}
