export declare class ClipByDirection {
    shouldClip: boolean;
    size: number | null;
    items: number | null;
    constructor();
    reset(): void;
}
export declare class ClipModel {
    forward: ClipByDirection;
    backward: ClipByDirection;
    constructor();
    reset(): void;
    readonly shouldClip: boolean;
}
