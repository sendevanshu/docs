import { BehaviorSubject } from 'rxjs';
import { Direction, State as IState, Process, PreviousClip, Run, ItemAdapter } from '../interfaces/index';
import { FetchModel } from './fetch';
import { ClipModel } from './clip';
export declare class State implements IState {
    process: Process;
    wfCycleCount: number;
    cycleCount: number;
    countDone: number;
    direction: Direction;
    scroll: boolean;
    fetch: FetchModel;
    clip: ClipModel;
    previousClip: PreviousClip;
    isInitial: boolean;
    pendingSource: BehaviorSubject<boolean>;
    firstVisibleSource: BehaviorSubject<ItemAdapter>;
    lastVisibleSource: BehaviorSubject<ItemAdapter>;
    pending: boolean;
    firstVisibleItem: ItemAdapter;
    lastVisibleItem: ItemAdapter;
    constructor();
    startCycle(options?: Run): void;
    endCycle(): void;
    setPreviousClip(reset?: boolean): void;
    getStartIndex(): number | null;
}
