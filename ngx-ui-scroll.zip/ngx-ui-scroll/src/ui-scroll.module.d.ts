export declare class UiScrollModule {
}
