import { Direction } from './direction';
export interface Run {
    direction?: Direction;
    scroll?: boolean;
}
