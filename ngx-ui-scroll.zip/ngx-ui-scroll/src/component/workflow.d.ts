import { BehaviorSubject } from 'rxjs';
import { UiScrollComponent } from '../ui-scroll.component';
import { Scroller } from './scroller';
import { ScrollHelper } from './classes/scrollHelper';
import { ProcessSubject } from './interfaces/index';
export declare class Workflow {
    scroller: Scroller;
    process$: BehaviorSubject<ProcessSubject>;
    cyclesDone: number;
    readonly context: UiScrollComponent;
    readonly scrollHelper: ScrollHelper;
    private onScrollUnsubscribe;
    private itemsSubscription;
    private workflowSubscription;
    constructor(context: UiScrollComponent);
    initListeners(): void;
    dispose(): void;
    callWorkflow(processSubject: ProcessSubject): void;
    process(data: ProcessSubject): void;
    done(): void;
    finalize(): void;
}
