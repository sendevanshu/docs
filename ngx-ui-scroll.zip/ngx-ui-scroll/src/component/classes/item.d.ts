import { Direction } from '../interfaces/direction';
import { Routines } from './domRoutines';
export declare class Item {
    $index: number;
    data: any;
    nodeId: string;
    routines: Routines;
    element: HTMLElement;
    invisible: boolean;
    toRemove: boolean;
    constructor($index: number, data: any, nodeId: string, routines: Routines);
    getParams(): ClientRect;
    getEdge(direction: Direction): number;
    hide(): void;
}
