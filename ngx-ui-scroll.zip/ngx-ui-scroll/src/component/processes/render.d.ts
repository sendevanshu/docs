import { Scroller } from '../scroller';
export default class Render {
    static run(scroller: Scroller): void;
    static setElements(scroller: Scroller): boolean;
}
