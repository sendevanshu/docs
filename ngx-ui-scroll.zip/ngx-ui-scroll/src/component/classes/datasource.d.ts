import { Datasource as IDatasource, DatasourceGet, DevSettings, Settings } from '../interfaces/index';
import { Adapter } from './adapter';
export declare class Datasource implements IDatasource {
    readonly constructed: boolean;
    get: DatasourceGet;
    settings?: Settings;
    devSettings?: DevSettings;
    adapter: Adapter;
    constructor(datasource: IDatasource, hasNoAdapter?: boolean);
}
