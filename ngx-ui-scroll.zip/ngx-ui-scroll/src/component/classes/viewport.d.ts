import { ElementRef } from '@angular/core';
import { Padding } from './padding';
import { Direction } from '../interfaces/index';
import { Routines } from './domRoutines';
import { Settings } from './settings';
export declare class ViewportPadding {
    forward: Padding;
    backward: Padding;
    constructor(element: HTMLElement, routines: Routines, settings: Settings);
    reset(): void;
}
export declare class Viewport {
    padding: ViewportPadding;
    syntheticScrollPosition: number | null;
    readonly element: HTMLElement;
    readonly host: HTMLElement;
    readonly scrollable: HTMLElement;
    readonly routines: Routines;
    private settings;
    constructor(elementRef: ElementRef, settings: Settings, routines: Routines);
    reset(): void;
    readonly scrollEventElement: HTMLElement | Document;
    readonly children: HTMLCollection;
    scrollPosition: number;
    getSize(): number;
    getBufferPadding(): number;
    getEdge(direction: Direction, opposite?: boolean): number;
    getElementEdge(element: HTMLElement, direction: Direction, opposite?: boolean): number;
    getLimit(direction: Direction, opposite?: boolean): number;
    isElementVisible(element: HTMLElement): boolean;
}
