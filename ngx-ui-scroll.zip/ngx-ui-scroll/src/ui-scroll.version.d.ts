declare const _default: "0.0.7";
export default _default;
