import { Direction } from '../interfaces/direction';
import { Routines } from './domRoutines';
export declare class Padding {
    element: HTMLElement;
    direction: Direction;
    routines: Routines;
    constructor(element: HTMLElement, direction: Direction, routines: Routines, initialSize?: number);
    reset(): void;
    size: number;
    getEdge(opposite?: boolean): number;
}
