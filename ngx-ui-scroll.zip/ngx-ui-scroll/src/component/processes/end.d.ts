import { Scroller } from '../scroller';
import { Run } from '../interfaces/index';
export default class End {
    static run(scroller: Scroller, isFail?: boolean): void;
    static calculateParams(scroller: Scroller): void;
    static getNextRun(scroller: Scroller): Run | null;
}
