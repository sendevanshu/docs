import { Settings as ISettings } from '../interfaces/index';
import { Settings } from '../classes/settings';
export declare const assignSettings: (target: Settings, settings: ISettings, defaults: ISettings, minSettings: ISettings) => void;
