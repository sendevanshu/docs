import { Scroller } from '../scroller';
import { Direction } from '../interfaces/index';
export default class Clip {
    static run(scroller: Scroller): void;
    static runByDirection(direction: Direction, scroller: Scroller): void;
    static processBuffer(scroller: Scroller): void;
    static processClip(scroller: Scroller): void;
}
