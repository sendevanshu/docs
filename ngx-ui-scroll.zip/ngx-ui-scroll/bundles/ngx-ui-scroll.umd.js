(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('rxjs'), require('rxjs/operators'), require('@angular/core'), require('@angular/common')) :
    typeof define === 'function' && define.amd ? define('ngx-ui-scroll', ['exports', 'rxjs', 'rxjs/operators', '@angular/core', '@angular/common'], factory) :
    (factory((global.ng = global.ng || {}, global.ng.ngxUiScroll = {}),global.rxjs,global.rxjs.operators,global.ng.core,global.ng.common));
}(this, (function (exports,rxjs,operators,core,common) { 'use strict';

    /**
     * @license ngx-ui-scroll
     * MIT license
     */

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var /** @type {?} */ checkDatasource = function (datasource) {
        if (!datasource) {
            throw new Error('No datasource provided');
        }
        if (!('get' in datasource)) {
            throw new Error('Datasource get method is not implemented');
        }
        if (typeof datasource.get !== 'function') {
            throw new Error('Datasource get is not a function');
        }
        if (datasource.get.length < 2) {
            throw new Error('Datasource get method invalid signature');
        }
        return datasource;
    };

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var /** @type {?} */ assignBoolean = function (target, source, token, defaults) {
        var /** @type {?} */ param = (/** @type {?} */ (source))[token];
        if (typeof param === 'undefined') {
            return;
        }
        if (typeof param !== 'boolean') {
            console.warn(token + ' setting parse error, set it to ' + (/** @type {?} */ (defaults))[token] + ' (default)');
            return;
        }
        (/** @type {?} */ (target))[token] = param;
        return true;
    };
    var /** @type {?} */ assignNumeric = function (target, source, token, defaults, integer) {
        if (integer === void 0) { integer = false; }
        var /** @type {?} */ param = (/** @type {?} */ (source))[token];
        if (typeof param === 'undefined') {
            return;
        }
        if (typeof param !== 'number') {
            console.warn(token + ' setting parse error, set it to ' + (/** @type {?} */ (defaults))[token] + ' (default)');
            return;
        }
        if (integer && parseInt(param.toString(), 10) !== param) {
            console.warn(token + ' setting parse error, set it to ' + (/** @type {?} */ (defaults))[token] + ' (default)');
            return;
        }
        (/** @type {?} */ (target))[token] = param;
        return true;
    };
    var /** @type {?} */ assignMinimalNumeric = function (target, source, token, defaults, minSettings, integer) {
        if (integer === void 0) { integer = false; }
        if (assignNumeric(target, source, token, defaults, integer) !== true) {
            return;
        }
        if ((/** @type {?} */ (target))[token] < (/** @type {?} */ (minSettings))[token]) {
            console.warn(token + ' setting is less than minimum, set it to ' + (/** @type {?} */ (minSettings))[token]);
            (/** @type {?} */ (target))[token] = (/** @type {?} */ (minSettings))[token];
            return;
        }
        return true;
    };
    var /** @type {?} */ assignSettings = function (target, settings, defaults, minSettings) {
        Object.assign(target, defaults);
        if (typeof settings === 'undefined') {
            return;
        }
        if (typeof settings !== 'object') {
            console.warn('settings is not an object, fallback to the defaults');
            return;
        }
        assignBoolean(target, settings, 'adapter', defaults);
        assignNumeric(target, settings, 'startIndex', defaults);
        assignMinimalNumeric(target, settings, 'bufferSize', defaults, minSettings, true);
        assignMinimalNumeric(target, settings, 'padding', defaults, minSettings);
        assignBoolean(target, settings, 'infinite', defaults);
        assignBoolean(target, settings, 'horizontal', defaults);
        assignBoolean(target, settings, 'windowViewport', defaults);
    };

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    /** @enum {string} */
    var Direction = {
        forward: 'forward',
        backward: 'backward',
    };

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    /** @enum {string} */
    var Process = {
        init: 'init',
        scroll: 'scroll',
        reload: 'reload',
        start: 'start',
        preFetch: 'preFetch',
        fetch: 'fetch',
        postFetch: 'postFetch',
        render: 'render',
        postRender: 'postRender',
        preClip: 'preClip',
        clip: 'clip',
        end: 'end',
    };

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var /** @type {?} */ getIsInitialized = function (adapter) {
        return rxjs.Observable.create(function (observer) {
            var /** @type {?} */ intervalId = setInterval(function () {
                if (adapter && adapter.init) {
                    clearInterval(intervalId);
                    observer.next(true);
                    observer.complete();
                }
            }, 25);
        });
    };
    var /** @type {?} */ getInitializedSubject = function (adapter, method) {
        return adapter.init ? method() :
            adapter.init$
                .pipe(operators.switchMap(function () {
                return method();
            }));
    };
    var /** @type {?} */ generateMockAdapter = function () { return (/** @type {?} */ ({
        version: null,
        init: false,
        init$: rxjs.of(false),
        isLoading: false,
        isLoading$: new rxjs.BehaviorSubject(false),
        firstVisible: {},
        firstVisible$: new rxjs.BehaviorSubject({}),
        lastVisible: {},
        lastVisible$: new rxjs.BehaviorSubject({}),
        itemsCount: 0,
        reload: function () { return null; }
    })); };
    var Adapter = /** @class */ (function () {
        function Adapter() {
            this.isInitialized = false;
        }
        Object.defineProperty(Adapter.prototype, "init", {
            get: /**
             * @return {?}
             */
            function () {
                return this.isInitialized;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Adapter.prototype, "init$", {
            get: /**
             * @return {?}
             */
            function () {
                return getIsInitialized(this);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Adapter.prototype, "version", {
            get: /**
             * @return {?}
             */
            function () {
                return this.isInitialized ? this.getVersion() : null;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Adapter.prototype, "isLoading", {
            get: /**
             * @return {?}
             */
            function () {
                return this.isInitialized ? this.getIsLoading() : false;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Adapter.prototype, "isLoading$", {
            get: /**
             * @return {?}
             */
            function () {
                var _this = this;
                return getInitializedSubject(this, function () { return _this.getIsLoading$(); });
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Adapter.prototype, "firstVisible", {
            get: /**
             * @return {?}
             */
            function () {
                return this.isInitialized ? this.getFirstVisible() : {};
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Adapter.prototype, "firstVisible$", {
            get: /**
             * @return {?}
             */
            function () {
                var _this = this;
                return getInitializedSubject(this, function () { return _this.getFirstVisible$(); });
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Adapter.prototype, "lastVisible", {
            get: /**
             * @return {?}
             */
            function () {
                return this.isInitialized ? this.getLastVisible() : {};
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Adapter.prototype, "lastVisible$", {
            get: /**
             * @return {?}
             */
            function () {
                var _this = this;
                return getInitializedSubject(this, function () { return _this.getLastVisible$(); });
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Adapter.prototype, "itemsCount", {
            get: /**
             * @return {?}
             */
            function () {
                return this.getItemsCount();
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @param {?} scroller
         * @return {?}
         */
        Adapter.prototype.initialize = /**
         * @param {?} scroller
         * @return {?}
         */
        function (scroller) {
            if (!this.isInitialized) {
                this.isInitialized = true;
                this.callWorkflow = scroller.callWorkflow;
                this.getVersion = function () { return scroller.version; };
                this.getIsLoading = function () { return scroller.state.pendingSource.getValue(); };
                this.getIsLoading$ = function () { return scroller.state.pendingSource; };
                this.getFirstVisible = function () { return scroller.state.firstVisibleSource.getValue(); };
                this.getFirstVisible$ = function () { return scroller.state.firstVisibleSource; };
                this.getLastVisible = function () { return scroller.state.lastVisibleSource.getValue(); };
                this.getLastVisible$ = function () { return scroller.state.lastVisibleSource; };
                this.getItemsCount = function () {
                    return scroller.buffer.items.reduce(function (acc, item) { return acc + (item.invisible ? 0 : 1); }, 0);
                };
            }
        };
        /**
         * @param {?=} reloadIndex
         * @return {?}
         */
        Adapter.prototype.reload = /**
         * @param {?=} reloadIndex
         * @return {?}
         */
        function (reloadIndex) {
            this.callWorkflow(/** @type {?} */ ({
                process: Process.reload,
                status: 'start',
                payload: reloadIndex
            }));
        };
        return Adapter;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var Datasource = /** @class */ (function () {
        function Datasource(datasource, hasNoAdapter) {
            this.constructed = true;
            Object.assign(/** @type {?} */ (this), datasource);
            if (hasNoAdapter) {
                this.adapter = /** @type {?} */ (generateMockAdapter());
            }
            else {
                this.adapter = new Adapter();
            }
        }
        return Datasource;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var /** @type {?} */ defaultSettings = {
        adapter: false,
        startIndex: 1,
        bufferSize: 5,
        padding: 0.5,
        infinite: false,
        horizontal: false,
        windowViewport: false
    };
    var /** @type {?} */ minSettings = {
        bufferSize: 1,
        padding: 0.01
    };
    var /** @type {?} */ defaultDevSettings = {
        debug: false,
        // logging is enabled if true; need to turn off in release
        immediateLog: true,
        // logging is not immediate if false, it could be forced via Workflow.logForce call
        clipAfterFetchOnly: true,
        clipAfterScrollOnly: true,
        paddingForwardSize: 0,
        paddingBackwardSize: 0,
        throttle: 40
    };
    var Settings = /** @class */ (function () {
        function Settings(settings, devSettings, instanceIndex) {
            assignSettings(this, settings || {}, defaultSettings || {}, minSettings);
            Object.assign(this, defaultDevSettings, devSettings);
            this.currentStartIndex = this.startIndex;
            this.instanceIndex = instanceIndex;
        }
        /**
         * @param {?} startIndex
         * @return {?}
         */
        Settings.prototype.setCurrentStartIndex = /**
         * @param {?} startIndex
         * @return {?}
         */
        function (startIndex) {
            startIndex = Number(startIndex);
            this.currentStartIndex = !isNaN(startIndex) ? startIndex : this.startIndex;
        };
        return Settings;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var Routines = /** @class */ (function () {
        function Routines(settings) {
            this.horizontal = settings.horizontal;
        }
        /**
         * @param {?} element
         * @return {?}
         */
        Routines.prototype.getScrollPosition = /**
         * @param {?} element
         * @return {?}
         */
        function (element) {
            return element[this.horizontal ? 'scrollLeft' : 'scrollTop'];
        };
        /**
         * @param {?} element
         * @param {?} value
         * @return {?}
         */
        Routines.prototype.setScrollPosition = /**
         * @param {?} element
         * @param {?} value
         * @return {?}
         */
        function (element, value) {
            element[this.horizontal ? 'scrollLeft' : 'scrollTop'] = value;
        };
        /**
         * @param {?} element
         * @return {?}
         */
        Routines.prototype.getParams = /**
         * @param {?} element
         * @return {?}
         */
        function (element) {
            if (element.tagName.toLowerCase() === 'body') {
                element = /** @type {?} */ (element.parentElement);
                return /** @type {?} */ ({
                    'height': element.clientHeight,
                    'width': element.clientWidth,
                    'top': element.clientTop,
                    'bottom': element.clientTop + element.clientHeight,
                    'left': element.clientLeft,
                    'right': element.clientLeft + element.clientWidth
                });
            }
            return element.getBoundingClientRect();
        };
        /**
         * @param {?} element
         * @return {?}
         */
        Routines.prototype.getSize = /**
         * @param {?} element
         * @return {?}
         */
        function (element) {
            return this.getParams(element)[this.horizontal ? 'width' : 'height'];
        };
        /**
         * @param {?} element
         * @return {?}
         */
        Routines.prototype.getSizeStyle = /**
         * @param {?} element
         * @return {?}
         */
        function (element) {
            var /** @type {?} */ size = element.style[this.horizontal ? 'width' : 'height'];
            return parseInt(/** @type {?} */ (size), 10) || 0;
        };
        /**
         * @param {?} element
         * @param {?} value
         * @return {?}
         */
        Routines.prototype.setSizeStyle = /**
         * @param {?} element
         * @param {?} value
         * @return {?}
         */
        function (element, value) {
            element.style[this.horizontal ? 'width' : 'height'] = value + "px";
        };
        /**
         * @param {?} params
         * @param {?} direction
         * @param {?=} opposite
         * @return {?}
         */
        Routines.prototype.getRectEdge = /**
         * @param {?} params
         * @param {?} direction
         * @param {?=} opposite
         * @return {?}
         */
        function (params, direction, opposite) {
            var /** @type {?} */ forward = !opposite ? Direction.forward : Direction.backward;
            return params[direction === forward ? (this.horizontal ? 'right' : 'bottom') : (this.horizontal ? 'left' : 'top')];
        };
        /**
         * @param {?} element
         * @param {?} direction
         * @param {?=} opposite
         * @return {?}
         */
        Routines.prototype.getEdge = /**
         * @param {?} element
         * @param {?} direction
         * @param {?=} opposite
         * @return {?}
         */
        function (element, direction, opposite) {
            var /** @type {?} */ params = this.getParams(element);
            return this.getRectEdge(params, direction, opposite);
        };
        /**
         * @param {?} element
         * @param {?} direction
         * @param {?} relativeElement
         * @param {?} opposite
         * @return {?}
         */
        Routines.prototype.getEdge2 = /**
         * @param {?} element
         * @param {?} direction
         * @param {?} relativeElement
         * @param {?} opposite
         * @return {?}
         */
        function (element, direction, relativeElement, opposite) {
            // vertical only ?
            return element.offsetTop - (relativeElement ? relativeElement.scrollTop : 0) +
                (direction === (!opposite ? Direction.forward : Direction.backward) ? this.getSize(element) : 0);
        };
        /**
         * @param {?} element
         * @return {?}
         */
        Routines.prototype.hideElement = /**
         * @param {?} element
         * @return {?}
         */
        function (element) {
            element.style.display = 'none';
        };
        return Routines;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var Padding = /** @class */ (function () {
        function Padding(element, direction, routines, initialSize) {
            this.element = /** @type {?} */ (element.querySelector("[data-padding-" + direction + "]"));
            this.direction = direction;
            this.routines = routines;
            if (initialSize) {
                this.routines.setSizeStyle(this.element, initialSize);
            }
        }
        /**
         * @return {?}
         */
        Padding.prototype.reset = /**
         * @return {?}
         */
        function () {
            this.size = 0;
        };
        Object.defineProperty(Padding.prototype, "size", {
            get: /**
             * @return {?}
             */
            function () {
                return this.routines.getSizeStyle(this.element);
            },
            set: /**
             * @param {?} value
             * @return {?}
             */
            function (value) {
                this.routines.setSizeStyle(this.element, Math.round(value));
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @param {?=} opposite
         * @return {?}
         */
        Padding.prototype.getEdge = /**
         * @param {?=} opposite
         * @return {?}
         */
        function (opposite) {
            if (opposite === void 0) { opposite = true; }
            return this.routines.getEdge(this.element, this.direction, opposite);
        };
        return Padding;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var ViewportPadding = /** @class */ (function () {
        function ViewportPadding(element, routines, settings) {
            this.forward = new Padding(element, Direction.forward, routines, settings.paddingForwardSize);
            this.backward = new Padding(element, Direction.backward, routines, settings.paddingBackwardSize);
        }
        /**
         * @return {?}
         */
        ViewportPadding.prototype.reset = /**
         * @return {?}
         */
        function () {
            this.forward.reset();
            this.backward.reset();
        };
        return ViewportPadding;
    }());
    var Viewport = /** @class */ (function () {
        function Viewport(elementRef, settings, routines) {
            this.settings = settings;
            this.routines = routines;
            this.element = elementRef.nativeElement;
            this.padding = new ViewportPadding(this.element, this.routines, settings);
            this.syntheticScrollPosition = null;
            if (settings.windowViewport) {
                this.host = this.element.ownerDocument.body;
                this.scrollable = /** @type {?} */ (this.element.ownerDocument.documentElement);
            }
            else {
                this.host = /** @type {?} */ (this.element.parentElement);
                this.scrollable = /** @type {?} */ (this.element.parentElement);
            }
        }
        /**
         * @return {?}
         */
        Viewport.prototype.reset = /**
         * @return {?}
         */
        function () {
            this.scrollPosition = 0;
            this.syntheticScrollPosition = null;
            this.padding.reset();
        };
        Object.defineProperty(Viewport.prototype, "scrollEventElement", {
            get: /**
             * @return {?}
             */
            function () {
                return this.settings.windowViewport ? this.element.ownerDocument : this.host;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Viewport.prototype, "children", {
            get: /**
             * @return {?}
             */
            function () {
                return this.element.children;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Viewport.prototype, "scrollPosition", {
            get: /**
             * @return {?}
             */
            function () {
                return this.routines.getScrollPosition(this.scrollable);
            },
            set: /**
             * @param {?} value
             * @return {?}
             */
            function (value) {
                this.routines.setScrollPosition(this.scrollable, value);
                this.syntheticScrollPosition = this.scrollPosition;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @return {?}
         */
        Viewport.prototype.getSize = /**
         * @return {?}
         */
        function () {
            return this.routines.getSize(this.host);
        };
        /**
         * @return {?}
         */
        Viewport.prototype.getBufferPadding = /**
         * @return {?}
         */
        function () {
            return this.getSize() * this.settings.padding;
        };
        /**
         * @param {?} direction
         * @param {?=} opposite
         * @return {?}
         */
        Viewport.prototype.getEdge = /**
         * @param {?} direction
         * @param {?=} opposite
         * @return {?}
         */
        function (direction, opposite) {
            return this.routines.getEdge(this.host, direction, opposite);
        };
        /**
         * @param {?} element
         * @param {?} direction
         * @param {?=} opposite
         * @return {?}
         */
        Viewport.prototype.getElementEdge = /**
         * @param {?} element
         * @param {?} direction
         * @param {?=} opposite
         * @return {?}
         */
        function (element, direction, opposite) {
            return this.routines.getEdge(element, direction, opposite);
        };
        /**
         * @param {?} direction
         * @param {?=} opposite
         * @return {?}
         */
        Viewport.prototype.getLimit = /**
         * @param {?} direction
         * @param {?=} opposite
         * @return {?}
         */
        function (direction, opposite) {
            return this.getEdge(direction, opposite) +
                (direction === (!opposite ? Direction.forward : Direction.backward) ? 1 : -1) * this.getBufferPadding();
        };
        /**
         * @param {?} element
         * @return {?}
         */
        Viewport.prototype.isElementVisible = /**
         * @param {?} element
         * @return {?}
         */
        function (element) {
            var /** @type {?} */ elementEdge = this.routines.getEdge(element, Direction.forward);
            var /** @type {?} */ viewportEdge = this.getEdge(Direction.backward);
            return elementEdge > viewportEdge;
        };
        return Viewport;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var ItemCache = /** @class */ (function () {
        function ItemCache(item) {
            this.$index = item.$index;
            this.nodeId = item.nodeId;
            this.data = item.data;
            this.params = item.getParams();
        }
        return ItemCache;
    }());
    var Cache = /** @class */ (function () {
        function Cache() {
            this.items = [];
        }
        /**
         * @param {?} item
         * @return {?}
         */
        Cache.prototype.add = /**
         * @param {?} item
         * @return {?}
         */
        function (item) {
            var /** @type {?} */ found = this.items.find(function (i) { return i.$index === item.$index; });
            if (found) {
                found.data = item.data;
                found.params = item.getParams();
            }
            else {
                // todo: do we need the list to be sorted? maybe an object?
                this.items.push(new ItemCache(item));
            }
        };
        /**
         * @param {?} index
         * @return {?}
         */
        Cache.prototype.get = /**
         * @param {?} index
         * @return {?}
         */
        function (index) {
            return this.items.find(function (i) { return i.$index === index; });
        };
        return Cache;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var Index = /** @class */ (function () {
        function Index() {
            this.reset();
        }
        /**
         * @return {?}
         */
        Index.prototype.reset = /**
         * @return {?}
         */
        function () {
            this.backward = null;
            this.forward = null;
        };
        return Index;
    }());
    var Buffer = /** @class */ (function () {
        function Buffer() {
            this.$items = new rxjs.BehaviorSubject(null);
            this.lastIndex = new Index();
            this.cache = new Cache();
            this.reset();
        }
        /**
         * @param {?=} reload
         * @return {?}
         */
        Buffer.prototype.reset = /**
         * @param {?=} reload
         * @return {?}
         */
        function (reload) {
            var _this = this;
            if (reload) {
                this.items.forEach(function (item) {
                    if (item.element) {
                        _this.cache.add(item);
                        item.hide();
                    }
                });
            }
            this.items = [];
            this.bof = false;
            this.eof = false;
            this.lastIndex.reset();
        };
        Object.defineProperty(Buffer.prototype, "items", {
            get: /**
             * @return {?}
             */
            function () {
                return this._items;
            },
            set: /**
             * @param {?} items
             * @return {?}
             */
            function (items) {
                this._items = items;
                if (items.length) {
                    this.setLastIndices();
                }
                this.$items.next(items);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Buffer.prototype, "size", {
            get: /**
             * @return {?}
             */
            function () {
                return this._items.length;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @return {?}
         */
        Buffer.prototype.setLastIndices = /**
         * @return {?}
         */
        function () {
            this.lastIndex[Direction.backward] = this.items[0].$index;
            this.lastIndex[Direction.forward] = this.items[this.items.length - 1].$index;
        };
        /**
         * @return {?}
         */
        Buffer.prototype.getFirstVisibleItemIndex = /**
         * @return {?}
         */
        function () {
            var /** @type {?} */ length = this.items.length;
            for (var /** @type {?} */ i = 0; i < length; i++) {
                if (!this.items[i].invisible) {
                    return i;
                }
            }
            return -1;
        };
        /**
         * @return {?}
         */
        Buffer.prototype.getLastVisibleItemIndex = /**
         * @return {?}
         */
        function () {
            for (var /** @type {?} */ i = this.items.length - 1; i >= 0; i--) {
                if (!this.items[i].invisible) {
                    return i;
                }
            }
            return -1;
        };
        /**
         * @param {?} direction
         * @param {?=} opposite
         * @return {?}
         */
        Buffer.prototype.getEdgeVisibleItemIndex = /**
         * @param {?} direction
         * @param {?=} opposite
         * @return {?}
         */
        function (direction, opposite) {
            return direction === (!opposite ? Direction.forward : Direction.backward) ?
                this.getLastVisibleItemIndex() : this.getFirstVisibleItemIndex();
        };
        /**
         * @return {?}
         */
        Buffer.prototype.getFirstVisibleItem = /**
         * @return {?}
         */
        function () {
            var /** @type {?} */ index = this.getFirstVisibleItemIndex();
            if (index >= 0) {
                return this.items[index];
            }
        };
        /**
         * @return {?}
         */
        Buffer.prototype.getLastVisibleItem = /**
         * @return {?}
         */
        function () {
            var /** @type {?} */ index = this.getLastVisibleItemIndex();
            if (index >= 0) {
                return this.items[index];
            }
        };
        /**
         * @param {?} direction
         * @param {?=} opposite
         * @return {?}
         */
        Buffer.prototype.getEdgeVisibleItem = /**
         * @param {?} direction
         * @param {?=} opposite
         * @return {?}
         */
        function (direction, opposite) {
            return direction === (!opposite ? Direction.forward : Direction.backward) ?
                this.getLastVisibleItem() : this.getFirstVisibleItem();
        };
        return Buffer;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var FetchByDirection = /** @class */ (function () {
        function FetchByDirection() {
            this.count = 0;
            this.reset();
        }
        /**
         * @return {?}
         */
        FetchByDirection.prototype.reset = /**
         * @return {?}
         */
        function () {
            var /** @type {?} */ count = this.count;
            this.shouldFetch = false;
            this.startIndex = null;
            this._newItemsData = null;
            this.items = null;
            this.count = count;
        };
        Object.defineProperty(FetchByDirection.prototype, "newItemsData", {
            get: /**
             * @return {?}
             */
            function () {
                return this._newItemsData;
            },
            set: /**
             * @param {?} items
             * @return {?}
             */
            function (items) {
                this._newItemsData = items;
                this.count++;
            },
            enumerable: true,
            configurable: true
        });
        return FetchByDirection;
    }());
    var FetchModel = /** @class */ (function () {
        function FetchModel() {
            this.forward = new FetchByDirection();
            this.backward = new FetchByDirection();
        }
        /**
         * @return {?}
         */
        FetchModel.prototype.reset = /**
         * @return {?}
         */
        function () {
            this.forward.reset();
            this.backward.reset();
        };
        Object.defineProperty(FetchModel.prototype, "count", {
            get: /**
             * @return {?}
             */
            function () {
                return this.backward.count + this.forward.count;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(FetchModel.prototype, "items", {
            get: /**
             * @return {?}
             */
            function () {
                return (this.backward.items ? this.backward.items : []).concat(this.forward.items ? this.forward.items : []);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(FetchModel.prototype, "shouldFetch", {
            get: /**
             * @return {?}
             */
            function () {
                return this.forward.shouldFetch || this.backward.shouldFetch;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(FetchModel.prototype, "hasNewItems", {
            get: /**
             * @return {?}
             */
            function () {
                return !!((this.forward.newItemsData && this.forward.newItemsData.length) ||
                    (this.backward.newItemsData && this.backward.newItemsData.length));
            },
            enumerable: true,
            configurable: true
        });
        return FetchModel;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var ClipByDirection = /** @class */ (function () {
        function ClipByDirection() {
            this.reset();
        }
        /**
         * @return {?}
         */
        ClipByDirection.prototype.reset = /**
         * @return {?}
         */
        function () {
            this.shouldClip = false;
            this.size = null;
            this.items = null;
        };
        return ClipByDirection;
    }());
    var ClipModel = /** @class */ (function () {
        function ClipModel() {
            this.forward = new ClipByDirection();
            this.backward = new ClipByDirection();
            this.reset();
        }
        /**
         * @return {?}
         */
        ClipModel.prototype.reset = /**
         * @return {?}
         */
        function () {
            this.backward.reset();
            this.forward.reset();
        };
        Object.defineProperty(ClipModel.prototype, "shouldClip", {
            get: /**
             * @return {?}
             */
            function () {
                return this.forward.shouldClip || this.backward.shouldClip;
            },
            enumerable: true,
            configurable: true
        });
        return ClipModel;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var State = /** @class */ (function () {
        function State() {
            this.isInitial = false;
            this.wfCycleCount = 1;
            this.cycleCount = 0;
            this.countDone = 0;
            this.fetch = new FetchModel();
            this.clip = new ClipModel();
            this.setPreviousClip(true);
            this.pendingSource = new rxjs.BehaviorSubject(false);
            this.firstVisibleSource = new rxjs.BehaviorSubject({});
            this.lastVisibleSource = new rxjs.BehaviorSubject({});
        }
        Object.defineProperty(State.prototype, "pending", {
            get: /**
             * @return {?}
             */
            function () {
                return this.pendingSource.getValue();
            },
            set: /**
             * @param {?} value
             * @return {?}
             */
            function (value) {
                if (this.pending !== value) {
                    this.pendingSource.next(value);
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(State.prototype, "firstVisibleItem", {
            get: /**
             * @return {?}
             */
            function () {
                return this.firstVisibleSource.getValue();
            },
            set: /**
             * @param {?} item
             * @return {?}
             */
            function (item) {
                if (this.firstVisibleItem.$index !== item.$index) {
                    this.firstVisibleSource.next(item);
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(State.prototype, "lastVisibleItem", {
            get: /**
             * @return {?}
             */
            function () {
                return this.lastVisibleSource.getValue();
            },
            set: /**
             * @param {?} item
             * @return {?}
             */
            function (item) {
                if (this.lastVisibleItem.$index !== item.$index) {
                    this.lastVisibleSource.next(item);
                }
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @param {?=} options
         * @return {?}
         */
        State.prototype.startCycle = /**
         * @param {?=} options
         * @return {?}
         */
        function (options) {
            if (options === void 0) { options = {}; }
            this.pending = true;
            this.cycleCount++;
            this.process = Process.start;
            this.direction = options.direction || Direction.forward;
            this.scroll = options.scroll || false;
            this.fetch.reset();
            this.clip.reset();
        };
        /**
         * @return {?}
         */
        State.prototype.endCycle = /**
         * @return {?}
         */
        function () {
            this.pending = false;
            this.countDone++;
        };
        /**
         * @param {?=} reset
         * @return {?}
         */
        State.prototype.setPreviousClip = /**
         * @param {?=} reset
         * @return {?}
         */
        function (reset) {
            this.previousClip = {
                isSet: !reset,
                backwardSize: this.clip.backward.size,
                forwardSize: this.clip.forward.size,
                backwardItems: this.clip.backward.items,
                forwardItems: this.clip.forward.items,
                direction: this.direction
            };
        };
        /**
         * @return {?}
         */
        State.prototype.getStartIndex = /**
         * @return {?}
         */
        function () {
            return this.fetch[this.direction].startIndex;
        };
        return State;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var /** @type {?} */ instanceCount = 0;
    var Scroller = /** @class */ (function () {
        function Scroller(context, callWorkflow) {
            this.logs = [];
            var /** @type {?} */ datasource = /** @type {?} */ (checkDatasource(context.datasource));
            this.datasource = datasource;
            this.version = context.version;
            // this._bindData = () => context.changeDetector.markForCheck();
            this._bindData = function () { return context.changeDetector.detectChanges(); };
            this.callWorkflow = callWorkflow;
            this.cycleSubscriptions = [];
            this.settings = new Settings(datasource.settings, datasource.devSettings, ++instanceCount);
            this.routines = new Routines(this.settings);
            this.viewport = new Viewport(context.elementRef, this.settings, this.routines);
            this.buffer = new Buffer();
            this.state = new State();
            if (!datasource.constructed) {
                this.datasource = new Datasource(datasource, !this.settings.adapter);
                if (this.settings.adapter) {
                    this.datasource.adapter.initialize(this);
                }
            }
            else {
                this.datasource.adapter.initialize(this);
            }
        }
        /**
         * @return {?}
         */
        Scroller.prototype.bindData = /**
         * @return {?}
         */
        function () {
            this._bindData();
            return rxjs.Observable.create(function (observer) {
                setTimeout(function () {
                    observer.next(true);
                    observer.complete();
                });
            });
        };
        /**
         * @return {?}
         */
        Scroller.prototype.purgeCycleSubscriptions = /**
         * @return {?}
         */
        function () {
            this.cycleSubscriptions.forEach(function (item) { return item.unsubscribe(); });
            this.cycleSubscriptions = [];
        };
        /**
         * @return {?}
         */
        Scroller.prototype.dispose = /**
         * @return {?}
         */
        function () {
            this.purgeCycleSubscriptions();
        };
        /**
         * @return {?}
         */
        Scroller.prototype.finalize = /**
         * @return {?}
         */
        function () {
        };
        /**
         * @param {?=} str
         * @return {?}
         */
        Scroller.prototype.stat = /**
         * @param {?=} str
         * @return {?}
         */
        function (str) {
            if (this.settings.debug) {
                this.log((str ? str + ' — ' : '') +
                    'top: ' + this.viewport.scrollPosition + ', ' +
                    'bwd_p: ' + this.viewport.padding.backward.size + ', ' +
                    'fwd_p: ' + this.viewport.padding.forward.size + ', ' +
                    'items: ' + this.buffer.size);
            }
        };
        /**
         * @param {...?} args
         * @return {?}
         */
        Scroller.prototype.log = /**
         * @param {...?} args
         * @return {?}
         */
        function () {
            var args = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                args[_i] = arguments[_i];
            }
            if (this.settings.debug) {
                if (this.settings.immediateLog) {
                    console.log.apply(this, args);
                }
                else {
                    this.logs.push(args);
                }
            }
        };
        /**
         * @param {...?} args
         * @return {?}
         */
        Scroller.prototype.logForce = /**
         * @param {...?} args
         * @return {?}
         */
        function () {
            var _this = this;
            var args = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                args[_i] = arguments[_i];
            }
            if (this.settings.debug) {
                if (!this.settings.immediateLog && this.logs.length) {
                    this.logs.forEach(function (logArgs) { return console.log.apply(_this, logArgs); });
                    this.logs = [];
                }
                if (args.length) {
                    console.log.apply(this, args);
                }
            }
        };
        return Scroller;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var ScrollHelper = /** @class */ (function () {
        function ScrollHelper(workflow) {
            this.workflow = workflow;
            this.lastScrollTime = 0;
            this.scrollTimer = null;
            this.endSubscription = null;
        }
        /**
         * @return {?}
         */
        ScrollHelper.prototype.run = /**
         * @return {?}
         */
        function () {
            var _this = this;
            var /** @type {?} */ viewport = this.workflow.scroller.viewport;
            if (viewport.syntheticScrollPosition === viewport.scrollPosition) {
                var /** @type {?} */ ssp_1 = viewport.scrollPosition;
                setTimeout(function () {
                    if (ssp_1 === viewport.scrollPosition) {
                        viewport.syntheticScrollPosition = null;
                    }
                });
                return;
            }
            if (this.workflow.scroller.state.pending) {
                if (!this.endSubscription) {
                    this.endSubscription = this.workflow.process$.pipe(operators.filter(function (data) { return data.process === Process.end && data.status === 'done'; })).subscribe(function () {
                        if (_this.endSubscription) {
                            _this.endSubscription.unsubscribe();
                        }
                        _this.endSubscription = null;
                        _this.run();
                    });
                }
                return;
            }
            this.throttledScroll();
        };
        /**
         * @return {?}
         */
        ScrollHelper.prototype.throttledScroll = /**
         * @return {?}
         */
        function () {
            var _this = this;
            var /** @type {?} */ scroller = this.workflow.scroller;
            var /** @type {?} */ diff = this.lastScrollTime + scroller.settings.throttle - Date.now();
            if (this.scrollTimer) {
                clearTimeout(this.scrollTimer);
                this.scrollTimer = null;
            }
            if (diff < 0) {
                this.lastScrollTime = Date.now();
                this.lastScrollPosition = scroller.viewport.scrollPosition;
                this.processScroll();
            }
            else {
                this.scrollTimer = /** @type {?} */ (setTimeout(function () {
                    _this.run();
                    _this.scrollTimer = null;
                }, diff));
            }
        };
        /**
         * @return {?}
         */
        ScrollHelper.prototype.purgeProcesses = /**
         * @return {?}
         */
        function () {
            if (this.endSubscription) {
                this.endSubscription.unsubscribe();
                this.endSubscription = null;
            }
            if (this.scrollTimer) {
                clearTimeout(this.scrollTimer);
                this.scrollTimer = null;
            }
        };
        /**
         * @return {?}
         */
        ScrollHelper.prototype.processScroll = /**
         * @return {?}
         */
        function () {
            this.purgeProcesses();
            this.workflow.callWorkflow(/** @type {?} */ ({
                process: Process.scroll,
                status: 'next'
            }));
        };
        return ScrollHelper;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var Init = /** @class */ (function () {
        function Init() {
        }
        /**
         * @param {?} scroller
         * @param {?=} isScroll
         * @return {?}
         */
        Init.run = /**
         * @param {?} scroller
         * @param {?=} isScroll
         * @return {?}
         */
        function (scroller, isScroll) {
            var /** @type {?} */ logData = scroller.settings.instanceIndex + "-" + scroller.state.wfCycleCount;
            var /** @type {?} */ logStyles = 'color: #0000aa; border: solid black 1px; border-width: 1px 0 0 1px; margin-left: -2px';
            scroller.log("%c   ~~~ WF Run " + logData + " STARTED ~~~  ", logStyles);
            scroller.state.isInitial = true;
            scroller.callWorkflow(/** @type {?} */ ({
                process: Process.init,
                status: 'next',
                payload: /** @type {?} */ ({
                    direction: Direction.forward,
                    scroll: !!isScroll
                })
            }));
        };
        return Init;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var Reload = /** @class */ (function () {
        function Reload() {
        }
        /**
         * @param {?} scroller
         * @param {?} reloadIndex
         * @return {?}
         */
        Reload.run = /**
         * @param {?} scroller
         * @param {?} reloadIndex
         * @return {?}
         */
        function (scroller, reloadIndex) {
            var /** @type {?} */ scrollPosition = scroller.viewport.scrollPosition;
            scroller.buffer.reset(true);
            scroller.viewport.reset();
            scroller.viewport.syntheticScrollPosition = scrollPosition > 0 ? 0 : null;
            scroller.purgeCycleSubscriptions();
            scroller.settings.setCurrentStartIndex(reloadIndex);
            // todo: do we need to emit Process.end before?
            scroller.callWorkflow(/** @type {?} */ ({
                process: Process.reload,
                status: 'next'
            }));
        };
        return Reload;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var Start = /** @class */ (function () {
        function Start() {
        }
        /**
         * @param {?} scroller
         * @param {?=} options
         * @return {?}
         */
        Start.run = /**
         * @param {?} scroller
         * @param {?=} options
         * @return {?}
         */
        function (scroller, options) {
            if (options === void 0) { options = {}; }
            if (!options.direction) {
                options.direction = scroller.state.direction || Direction.forward;
            }
            scroller.state.startCycle(options);
            var /** @type {?} */ logData = scroller.settings.instanceIndex + "-" + scroller.state.wfCycleCount + "-" + scroller.state.cycleCount;
            scroller.log("%c---=== Workflow " + logData + " start", 'color: #006600;', options);
            scroller.callWorkflow(/** @type {?} */ ({
                process: Process.start,
                status: 'next'
            }));
        };
        return Start;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var PreFetch = /** @class */ (function () {
        function PreFetch() {
        }
        /**
         * @param {?} scroller
         * @return {?}
         */
        PreFetch.run = /**
         * @param {?} scroller
         * @return {?}
         */
        function (scroller) {
            scroller.state.process = Process.preFetch;
            var /** @type {?} */ direction = scroller.state.direction;
            var /** @type {?} */ paddingEdge = scroller.viewport.padding[direction].getEdge();
            var /** @type {?} */ limit = scroller.viewport.getLimit(direction);
            scroller.state.fetch[direction].shouldFetch = PreFetch.checkEOF(scroller) ? false :
                (direction === Direction.forward) ? paddingEdge < limit : paddingEdge > limit;
            var /** @type {?} */ shouldFetch = scroller.state.fetch[direction].shouldFetch;
            if (shouldFetch) {
                PreFetch.setStartIndex(scroller);
                PreFetch.processPreviousClip(scroller);
            }
            scroller.callWorkflow(/** @type {?} */ ({
                process: Process.preFetch,
                status: shouldFetch ? 'next' : 'done'
            }));
        };
        /**
         * @param {?} scroller
         * @return {?}
         */
        PreFetch.checkEOF = /**
         * @param {?} scroller
         * @return {?}
         */
        function (scroller) {
            return (scroller.state.direction === Direction.forward && scroller.buffer.eof) ||
                (scroller.state.direction === Direction.backward && scroller.buffer.bof);
        };
        /**
         * @param {?} scroller
         * @return {?}
         */
        PreFetch.setStartIndex = /**
         * @param {?} scroller
         * @return {?}
         */
        function (scroller) {
            var /** @type {?} */ direction = scroller.state.direction;
            var /** @type {?} */ forward = direction === Direction.forward;
            var /** @type {?} */ back = -scroller.settings.bufferSize;
            var /** @type {?} */ lastIndex = scroller.buffer.lastIndex[direction];
            var /** @type {?} */ start;
            if (lastIndex === null) {
                start = scroller.settings.currentStartIndex + (forward ? 0 : back);
            }
            else {
                start = lastIndex + (forward ? 1 : back);
            }
            scroller.state.fetch[direction].startIndex = start;
        };
        /**
         * @param {?} scroller
         * @return {?}
         */
        PreFetch.processPreviousClip = /**
         * @param {?} scroller
         * @return {?}
         */
        function (scroller) {
            var /** @type {?} */ previousClip = scroller.state.previousClip;
            if (!previousClip.isSet) {
                return;
            }
            var /** @type {?} */ direction = scroller.state.direction;
            var /** @type {?} */ forward = direction === Direction.forward;
            var /** @type {?} */ opposite = forward ? Direction.backward : Direction.forward;
            var /** @type {?} */ clipSize = (/** @type {?} */ (previousClip))[opposite + "Size"];
            if (clipSize && previousClip.direction !== scroller.state.direction) {
                scroller.viewport.padding[direction].size -= clipSize;
                scroller.viewport.padding[opposite].size += clipSize;
                if (!forward) {
                    scroller.buffer.lastIndex[opposite] = (scroller.buffer.lastIndex[direction] || 0) - 1;
                }
                else {
                    scroller.buffer.lastIndex[direction] = scroller.buffer.lastIndex[opposite];
                }
            }
            scroller.state.setPreviousClip(true);
        };
        return PreFetch;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var Fetch = /** @class */ (function () {
        function Fetch() {
        }
        /**
         * @param {?} scroller
         * @return {?}
         */
        Fetch.run = /**
         * @param {?} scroller
         * @return {?}
         */
        function (scroller) {
            scroller.state.process = Process.fetch;
            var /** @type {?} */ result = Fetch.get(scroller);
            if (typeof result.subscribe !== 'function') {
                if (!result.isError) {
                    Fetch.success(result.data, scroller);
                }
                else {
                    Fetch.fail(result.error, scroller);
                }
            }
            else {
                scroller.cycleSubscriptions.push(result.subscribe(function (data) { return Fetch.success(data, scroller); }, function (error) { return Fetch.fail(error, scroller); }));
            }
        };
        /**
         * @param {?} data
         * @param {?} scroller
         * @return {?}
         */
        Fetch.success = /**
         * @param {?} data
         * @param {?} scroller
         * @return {?}
         */
        function (data, scroller) {
            var /** @type {?} */ direction = scroller.state.direction;
            scroller.log("resolved " + data.length + " " + direction + " items " +
                ("(index = " + scroller.state.fetch[direction].startIndex + ", count = " + scroller.settings.bufferSize + ")"));
            scroller.state.fetch[direction].newItemsData = data;
            scroller.callWorkflow(/** @type {?} */ ({
                process: Process.fetch,
                status: 'next'
            }));
        };
        /**
         * @param {?} error
         * @param {?} scroller
         * @return {?}
         */
        Fetch.fail = /**
         * @param {?} error
         * @param {?} scroller
         * @return {?}
         */
        function (error, scroller) {
            scroller.callWorkflow(/** @type {?} */ ({
                process: Process.fetch,
                status: 'error',
                payload: error
            }));
        };
        /**
         * @param {?} scroller
         * @return {?}
         */
        Fetch.get = /**
         * @param {?} scroller
         * @return {?}
         */
        function (scroller) {
            var /** @type {?} */ _get = /** @type {?} */ (scroller.datasource.get);
            var /** @type {?} */ immediateData, /** @type {?} */ immediateError;
            var /** @type {?} */ observer;
            var /** @type {?} */ success = function (data) {
                if (!observer) {
                    immediateData = data || null;
                    return;
                }
                observer.next(data);
                observer.complete();
            };
            var /** @type {?} */ reject = function (error) {
                if (!observer) {
                    immediateError = error || null;
                    return;
                }
                observer.error(error);
            };
            var /** @type {?} */ result = _get(scroller.state.getStartIndex(), scroller.settings.bufferSize, success, reject);
            if (result && typeof result.then === 'function') {
                // DatasourceGetPromise
                result.then(success, reject);
            }
            else if (result && typeof result.subscribe === 'function') {
                // DatasourceGetObservable
                return result; // do not wrap observable
            }
            if (immediateData !== undefined || immediateError !== undefined) {
                return {
                    data: immediateData,
                    error: immediateError,
                    isError: immediateError !== undefined
                };
            }
            return rxjs.Observable.create(function (_observer) {
                observer = _observer;
            });
        };
        return Fetch;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var Item = /** @class */ (function () {
        function Item($index, data, nodeId, routines) {
            this.$index = $index;
            this.data = data;
            this.nodeId = nodeId;
            this.routines = routines;
            this.invisible = true;
        }
        /**
         * @return {?}
         */
        Item.prototype.getParams = /**
         * @return {?}
         */
        function () {
            return this.routines.getParams(this.element);
        };
        /**
         * @param {?} direction
         * @return {?}
         */
        Item.prototype.getEdge = /**
         * @param {?} direction
         * @return {?}
         */
        function (direction) {
            return this.routines.getEdge(this.element, direction, false);
        };
        /**
         * @return {?}
         */
        Item.prototype.hide = /**
         * @return {?}
         */
        function () {
            this.routines.hideElement(this.element);
        };
        return Item;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var PostFetch = /** @class */ (function () {
        function PostFetch() {
        }
        /**
         * @param {?} scroller
         * @return {?}
         */
        PostFetch.run = /**
         * @param {?} scroller
         * @return {?}
         */
        function (scroller) {
            scroller.state.process = Process.postFetch;
            PostFetch.setEOF(scroller);
            var /** @type {?} */ hasItems = PostFetch.setItems(scroller);
            scroller.callWorkflow(/** @type {?} */ ({
                process: Process.postFetch,
                status: hasItems ? 'next' : 'done'
            }));
        };
        /**
         * @param {?} scroller
         * @return {?}
         */
        PostFetch.setEOF = /**
         * @param {?} scroller
         * @return {?}
         */
        function (scroller) {
            var /** @type {?} */ direction = scroller.state.direction;
            var /** @type {?} */ fetch = scroller.state.fetch[direction];
            var /** @type {?} */ eof = direction === Direction.forward ? 'eof' : 'bof';
            var /** @type {?} */ items = /** @type {?} */ (fetch.newItemsData);
            scroller.buffer[eof] = items.length !== scroller.settings.bufferSize;
            if (direction === Direction.backward && scroller.buffer.bof) {
                fetch.startIndex = /** @type {?} */ (fetch.startIndex) + scroller.settings.bufferSize - items.length;
            }
        };
        /**
         * @param {?} scroller
         * @return {?}
         */
        PostFetch.setItems = /**
         * @param {?} scroller
         * @return {?}
         */
        function (scroller) {
            var /** @type {?} */ direction = scroller.state.direction;
            var /** @type {?} */ fetch = scroller.state.fetch[direction];
            var /** @type {?} */ items = /** @type {?} */ (fetch.newItemsData);
            if (!items.length) {
                // empty result
                return false;
            }
            fetch.items = items.map(function (item, index) {
                var /** @type {?} */ $index = /** @type {?} */ (fetch.startIndex) + index;
                var /** @type {?} */ nodeId = String($index);
                return new Item($index, item, nodeId, scroller.routines);
            });
            if (direction === Direction.forward) {
                scroller.buffer.items = scroller.buffer.items.concat(fetch.items);
            }
            else {
                scroller.buffer.items = fetch.items.concat(scroller.buffer.items);
            }
            return true;
        };
        return PostFetch;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var Render = /** @class */ (function () {
        function Render() {
        }
        /**
         * @param {?} scroller
         * @return {?}
         */
        Render.run = /**
         * @param {?} scroller
         * @return {?}
         */
        function (scroller) {
            scroller.state.process = Process.render;
            scroller.cycleSubscriptions.push(scroller.bindData().subscribe(function () {
                if (Render.setElements(scroller)) {
                    scroller.callWorkflow(/** @type {?} */ ({
                        process: Process.render,
                        status: 'next'
                    }));
                }
                else {
                    scroller.callWorkflow(/** @type {?} */ ({
                        process: Process.render,
                        status: 'error',
                        payload: 'Can not associate item with element'
                    }));
                }
            }));
        };
        /**
         * @param {?} scroller
         * @return {?}
         */
        Render.setElements = /**
         * @param {?} scroller
         * @return {?}
         */
        function (scroller) {
            var /** @type {?} */ items = scroller.state.fetch.items;
            for (var /** @type {?} */ j = items.length - 1; j >= 0; j--) {
                var /** @type {?} */ nodes = scroller.viewport.children;
                for (var /** @type {?} */ i = nodes.length - 1; i >= 0; i--) {
                    if (nodes[i].getAttribute('data-sid') === items[j].nodeId) {
                        items[j].element = /** @type {?} */ (nodes[i]);
                    }
                }
                if (!items[j].element) {
                    // todo: is this situation possible?
                    return false;
                }
            }
            return true;
        };
        return Render;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var PostRender = /** @class */ (function () {
        function PostRender() {
        }
        /**
         * @param {?} scroller
         * @return {?}
         */
        PostRender.run = /**
         * @param {?} scroller
         * @return {?}
         */
        function (scroller) {
            scroller.state.process = Process.postRender;
            var /** @type {?} */ viewport = scroller.viewport;
            var /** @type {?} */ direction = scroller.state.direction;
            var /** @type {?} */ items = /** @type {?} */ (scroller.state.fetch[direction].items);
            var /** @type {?} */ position = viewport.scrollPosition;
            PostRender.processFetchedItems(items);
            // pre-adjustment, scroll position only
            if (position !== viewport.scrollPosition) {
                viewport.scrollPosition = position;
            }
            // paddings and scroll position adjustments
            var /** @type {?} */ height = Math.round(Math.abs(items[0].getEdge(Direction.backward) - items[items.length - 1].getEdge(Direction.forward)));
            var /** @type {?} */ syntheticScrollPosition = null;
            if (direction === Direction.forward) {
                PostRender.runForward(scroller, height);
            }
            else {
                syntheticScrollPosition = PostRender.runBackward(scroller, height);
            }
            // post-adjustment, scroll position only
            if (position !== viewport.scrollPosition) {
                if (syntheticScrollPosition !== null) {
                    viewport.scrollPosition += viewport.scrollPosition - syntheticScrollPosition;
                }
                else {
                    viewport.scrollPosition = position;
                }
            }
            scroller.callWorkflow(/** @type {?} */ ({
                process: Process.postRender,
                status: 'next'
            }));
        };
        /**
         * @param {?} items
         * @return {?}
         */
        PostRender.processFetchedItems = /**
         * @param {?} items
         * @return {?}
         */
        function (items) {
            for (var /** @type {?} */ i = items.length - 1; i >= 0; i--) {
                var /** @type {?} */ element = items[i].element;
                element.style.left = '';
                element.style.position = '';
                items[i].invisible = false;
            }
        };
        /**
         * @param {?} scroller
         * @param {?} size
         * @return {?}
         */
        PostRender.runForward = /**
         * @param {?} scroller
         * @param {?} size
         * @return {?}
         */
        function (scroller, size) {
            var /** @type {?} */ paddingForward = scroller.viewport.padding[Direction.forward];
            var /** @type {?} */ _paddingSize = paddingForward.size || 0;
            paddingForward.size = Math.max(_paddingSize - size, 0);
        };
        /**
         * @param {?} scroller
         * @param {?} size
         * @return {?}
         */
        PostRender.runBackward = /**
         * @param {?} scroller
         * @param {?} size
         * @return {?}
         */
        function (scroller, size) {
            var /** @type {?} */ viewport = scroller.viewport;
            var /** @type {?} */ _scrollPosition = viewport.scrollPosition;
            var /** @type {?} */ paddingBackward = viewport.padding[Direction.backward];
            var /** @type {?} */ paddingForward = viewport.padding[Direction.forward];
            // need to make "size" pixels in backward direction
            // 1) via paddingTop
            var /** @type {?} */ _paddingSize = paddingBackward.size || 0;
            var /** @type {?} */ paddingSize = Math.max(_paddingSize - size, 0);
            paddingBackward.size = paddingSize;
            var /** @type {?} */ paddingDiff = size - (_paddingSize - paddingSize);
            // 2) via scrollTop
            if (paddingDiff > 0) {
                size = paddingDiff;
                viewport.scrollPosition += size;
                var /** @type {?} */ diff = size - viewport.scrollPosition - _scrollPosition;
                if (diff > 0) {
                    paddingSize = paddingForward.size || 0;
                    paddingForward.size = paddingSize + diff;
                    viewport.scrollPosition += diff;
                }
                return viewport.scrollPosition;
            }
            return null;
        };
        return PostRender;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var PreClip = /** @class */ (function () {
        function PreClip() {
        }
        /**
         * @param {?} scroller
         * @return {?}
         */
        PreClip.run = /**
         * @param {?} scroller
         * @return {?}
         */
        function (scroller) {
            scroller.state.process = Process.preClip;
            var /** @type {?} */ shouldNotClip = scroller.settings.infinite ||
                !scroller.buffer.size ||
                (scroller.settings.clipAfterScrollOnly && !scroller.state.scroll);
            if (!shouldNotClip) {
                var /** @type {?} */ afterFetch = scroller.settings.clipAfterFetchOnly;
                if (!afterFetch || scroller.state.fetch[Direction.backward].shouldFetch) {
                    PreClip.shouldClipByDirection(Direction.backward, scroller);
                }
                if (!afterFetch || scroller.state.fetch[Direction.forward].shouldFetch) {
                    PreClip.shouldClipByDirection(Direction.forward, scroller);
                }
                shouldNotClip = !scroller.state.clip.shouldClip;
            }
            scroller.callWorkflow(/** @type {?} */ ({
                process: Process.preClip,
                status: !shouldNotClip ? 'next' : 'done'
            }));
        };
        /**
         * @param {?} direction
         * @param {?} scroller
         * @return {?}
         */
        PreClip.shouldClipByDirection = /**
         * @param {?} direction
         * @param {?} scroller
         * @return {?}
         */
        function (direction, scroller) {
            var /** @type {?} */ items = scroller.buffer.items;
            var /** @type {?} */ forward = direction === Direction.forward;
            var /** @type {?} */ viewport = scroller.viewport;
            var /** @type {?} */ viewportLimit = viewport.getLimit(direction, true);
            var /** @type {?} */ firstIndex = scroller.buffer.getFirstVisibleItemIndex();
            var /** @type {?} */ lastIndex = scroller.buffer.getLastVisibleItemIndex();
            var /** @type {?} */ firstItemEdge = items[firstIndex].getEdge(direction);
            var /** @type {?} */ lastItemEdge = items[lastIndex].getEdge(direction);
            var /** @type {?} */ i, /** @type {?} */ itemEdge, /** @type {?} */ start = -1, /** @type {?} */ end = -1;
            var /** @type {?} */ getItemEdge = function (index) {
                return index === firstIndex ? firstItemEdge : (index === lastIndex ? lastItemEdge :
                    items[index].getEdge(direction));
            };
            if ((forward && lastItemEdge <= viewportLimit) || (!forward && firstItemEdge >= viewportLimit)) {
                // all items should be clipped
                start = firstIndex;
                end = lastIndex;
            }
            else {
                if (forward) {
                    start = firstIndex;
                }
                else {
                    end = lastIndex;
                }
                for (forward ? (i = 0) : (i = lastIndex); forward ? (i <= lastIndex) : (i >= 0); forward ? i++ : i--) {
                    itemEdge = getItemEdge(i);
                    if (forward && itemEdge <= viewportLimit) {
                        end = i;
                    }
                    else if (!forward && itemEdge >= viewportLimit) {
                        start = i;
                    }
                    else {
                        break;
                    }
                }
            }
            if (start >= 0 && end >= 0) {
                var /** @type {?} */ itemsToRemove = 0;
                for (i = start; i <= end; i++) {
                    items[i].toRemove = true;
                    itemsToRemove++;
                }
                scroller.state.clip[direction].shouldClip = true;
                scroller.state.clip[direction].size = items[end].getEdge(Direction.forward) - items[start].getEdge(Direction.backward);
                scroller.state.clip[direction].items = itemsToRemove;
            }
        };
        return PreClip;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var Clip = /** @class */ (function () {
        function Clip() {
        }
        /**
         * @param {?} scroller
         * @return {?}
         */
        Clip.run = /**
         * @param {?} scroller
         * @return {?}
         */
        function (scroller) {
            scroller.state.process = Process.clip;
            Clip.runByDirection(Direction.forward, scroller);
            Clip.runByDirection(Direction.backward, scroller);
            Clip.processBuffer(scroller);
            scroller.cycleSubscriptions.push(scroller.bindData().subscribe(function () {
                Clip.processClip(scroller);
                scroller.callWorkflow(/** @type {?} */ ({
                    process: Process.clip,
                    status: 'next'
                }));
            }));
        };
        /**
         * @param {?} direction
         * @param {?} scroller
         * @return {?}
         */
        Clip.runByDirection = /**
         * @param {?} direction
         * @param {?} scroller
         * @return {?}
         */
        function (direction, scroller) {
            if (!scroller.state.clip[direction].shouldClip) {
                return;
            }
            var /** @type {?} */ opposite = direction === Direction.forward ? Direction.backward : Direction.forward;
            scroller.viewport.padding[opposite].size += scroller.state.clip[direction].size || 0;
        };
        /**
         * @param {?} scroller
         * @return {?}
         */
        Clip.processBuffer = /**
         * @param {?} scroller
         * @return {?}
         */
        function (scroller) {
            var /** @type {?} */ clipped = [];
            scroller.buffer.items = scroller.buffer.items.filter(function (item) {
                if (item.toRemove) {
                    scroller.buffer.cache.add(item);
                    item.hide();
                    clipped.push(item.$index);
                    return false;
                }
                return true;
            });
            scroller.log("clipped " + clipped.length + " items", clipped);
            if (!scroller.buffer.size) {
                scroller.state.setPreviousClip();
            }
        };
        /**
         * @param {?} scroller
         * @return {?}
         */
        Clip.processClip = /**
         * @param {?} scroller
         * @return {?}
         */
        function (scroller) {
            if (!scroller.state.clip[Direction.backward].shouldClip) {
                scroller.buffer.bof = false;
            }
            if (!scroller.state.clip[Direction.forward].shouldClip) {
                scroller.buffer.eof = false;
            }
        };
        return Clip;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var End = /** @class */ (function () {
        function End() {
        }
        /**
         * @param {?} scroller
         * @param {?=} isFail
         * @return {?}
         */
        End.run = /**
         * @param {?} scroller
         * @param {?=} isFail
         * @return {?}
         */
        function (scroller, isFail) {
            scroller.state.endCycle();
            if (scroller.datasource.adapter.init) {
                End.calculateParams(scroller);
            }
            scroller.purgeCycleSubscriptions();
            scroller.finalize();
            var /** @type {?} */ next = null;
            var /** @type {?} */ logData = scroller.settings.instanceIndex + "-" + scroller.state.wfCycleCount + "-" + scroller.state.cycleCount;
            if (isFail) {
                scroller.log("%c---=== Workflow " + logData + " fail", 'color: #006600;');
            }
            else {
                scroller.log("%c---=== Workflow " + logData + " done", 'color: #006600;');
                next = End.getNextRun(scroller);
            }
            scroller.callWorkflow(/** @type {?} */ ({
                process: Process.end,
                status: next ? 'next' : 'done',
                payload: next
            }));
        };
        /**
         * @param {?} scroller
         * @return {?}
         */
        End.calculateParams = /**
         * @param {?} scroller
         * @return {?}
         */
        function (scroller) {
            var /** @type {?} */ items = scroller.buffer.items;
            var /** @type {?} */ length = items.length;
            var /** @type {?} */ viewportBackwardEdge = scroller.viewport.getEdge(Direction.backward);
            var /** @type {?} */ viewportForwardEdge = scroller.viewport.getEdge(Direction.forward);
            var /** @type {?} */ index = null;
            for (var /** @type {?} */ i = 0; i < length; i++) {
                var /** @type {?} */ edge = scroller.viewport.getElementEdge(items[i].element, Direction.backward, true);
                if (edge > viewportBackwardEdge) {
                    index = i;
                    break;
                }
            }
            scroller.state.firstVisibleItem = index !== null ? {
                $index: items[index].$index,
                data: items[index].data,
                element: items[index].element
            } : {};
            index = null;
            for (var /** @type {?} */ i = length - 1; i >= 0; i--) {
                var /** @type {?} */ edge = scroller.viewport.getElementEdge(items[i].element, Direction.forward, true);
                if (edge < viewportForwardEdge) {
                    index = i;
                    break;
                }
            }
            scroller.state.lastVisibleItem = index !== null ? {
                $index: items[index].$index,
                data: items[index].data,
                element: items[index].element
            } : {};
        };
        /**
         * @param {?} scroller
         * @return {?}
         */
        End.getNextRun = /**
         * @param {?} scroller
         * @return {?}
         */
        function (scroller) {
            var /** @type {?} */ nextRun = null;
            if (scroller.state.fetch.hasNewItems || scroller.state.clip.shouldClip) {
                nextRun = {
                    direction: scroller.state.direction,
                    scroll: scroller.state.scroll
                };
            }
            else if (!scroller.buffer.size && scroller.state.fetch.shouldFetch && !scroller.state.fetch.hasNewItems) {
                nextRun = {
                    direction: scroller.state.direction === Direction.forward ? Direction.backward : Direction.forward,
                    scroll: false
                };
            }
            else if (scroller.state.isInitial) {
                scroller.state.isInitial = false;
                nextRun = {
                    direction: Direction.backward,
                    scroll: scroller.state.scroll || false
                };
            }
            return nextRun;
        };
        return End;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var Workflow = /** @class */ (function () {
        function Workflow(context) {
            var _this = this;
            this.context = context;
            this.scroller = new Scroller(this.context, this.callWorkflow.bind(this));
            this.scrollHelper = new ScrollHelper(this);
            this.process$ = new rxjs.BehaviorSubject(/** @type {?} */ ({
                process: Process.init,
                status: 'start'
            }));
            this.cyclesDone = 0;
            setTimeout(function () { return _this.initListeners(); });
            this.scroller.log("The uiScroll Workflow has been initialized (" + this.context.version + ")");
        }
        /**
         * @return {?}
         */
        Workflow.prototype.initListeners = /**
         * @return {?}
         */
        function () {
            var _this = this;
            var /** @type {?} */ scroller = this.scroller;
            this.itemsSubscription = scroller.buffer.$items.subscribe(function (items) { return _this.context.items = items; });
            this.workflowSubscription = this.process$.subscribe(this.process.bind(this));
            this.onScrollUnsubscribe = this.context.renderer.listen(scroller.viewport.scrollEventElement, 'scroll', this.scrollHelper.run.bind(this.scrollHelper));
        };
        /**
         * @return {?}
         */
        Workflow.prototype.dispose = /**
         * @return {?}
         */
        function () {
            this.scrollHelper.purgeProcesses();
            this.onScrollUnsubscribe();
            this.process$.complete();
            this.workflowSubscription.unsubscribe();
            this.itemsSubscription.unsubscribe();
            this.scroller.dispose();
        };
        /**
         * @param {?} processSubject
         * @return {?}
         */
        Workflow.prototype.callWorkflow = /**
         * @param {?} processSubject
         * @return {?}
         */
        function (processSubject) {
            this.process$.next(processSubject);
        };
        /**
         * @param {?} data
         * @return {?}
         */
        Workflow.prototype.process = /**
         * @param {?} data
         * @return {?}
         */
        function (data) {
            var /** @type {?} */ scroller = this.scroller;
            var /** @type {?} */ pl = typeof data.payload === 'string' ? " (" + data.payload + ")" : '';
            scroller.log("process " + data.process + ", " + (data.status + pl));
            if (data.status === 'error') {
                End.run(scroller, true);
                return;
            }
            switch (data.process) {
                case Process.init:
                    if (data.status === 'start') {
                        Init.run(scroller);
                    }
                    if (data.status === 'next') {
                        Start.run(scroller, data.payload);
                    }
                    break;
                case Process.reload:
                    if (data.status === 'start') {
                        Reload.run(scroller, data.payload);
                    }
                    if (data.status === 'next') {
                        Init.run(scroller);
                    }
                    break;
                case Process.scroll:
                    if (data.status === 'next') {
                        Init.run(scroller, true);
                    }
                    break;
                case Process.start:
                    if (data.status === 'next') {
                        PreFetch.run(scroller);
                    }
                    break;
                case Process.preFetch:
                    if (data.status === 'next') {
                        Fetch.run(scroller);
                    }
                    if (data.status === 'done') {
                        End.run(scroller);
                    }
                    break;
                case Process.fetch:
                    if (data.status === 'next') {
                        PostFetch.run(scroller);
                    }
                    break;
                case Process.postFetch:
                    if (data.status === 'next') {
                        Render.run(scroller);
                    }
                    if (data.status === 'done') {
                        End.run(scroller);
                    }
                    break;
                case Process.render:
                    if (data.status === 'next') {
                        PostRender.run(scroller);
                    }
                    break;
                case Process.postRender:
                    if (data.status === 'next') {
                        PreClip.run(scroller);
                    }
                    break;
                case Process.preClip:
                    if (data.status === 'next') {
                        Clip.run(scroller);
                    }
                    if (data.status === 'done') {
                        End.run(scroller);
                    }
                    break;
                case Process.clip:
                    if (data.status === 'next') {
                        End.run(scroller);
                    }
                    break;
                case Process.end:
                    if (data.status === 'next') {
                        Start.run(scroller, data.payload);
                    }
                    if (data.status === 'done') {
                        this.done();
                    }
                    break;
            }
        };
        /**
         * @return {?}
         */
        Workflow.prototype.done = /**
         * @return {?}
         */
        function () {
            this.cyclesDone++;
            this.scroller.state.wfCycleCount = this.cyclesDone + 1;
            var /** @type {?} */ logData = this.scroller.settings.instanceIndex + "-" + this.cyclesDone;
            var /** @type {?} */ logStyles = 'color: #0000aa; border: solid #555 1px; border-width: 0 0 1px 1px; margin-left: -2px';
            this.scroller.log("%c   ~~~ WF Run " + logData + " FINALIZED ~~~  ", logStyles);
            this.finalize();
        };
        /**
         * @return {?}
         */
        Workflow.prototype.finalize = /**
         * @return {?}
         */
        function () {
        };
        return Workflow;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var UiScrollComponent = /** @class */ (function () {
        function UiScrollComponent(changeDetector, elementRef, renderer) {
            this.changeDetector = changeDetector;
            this.elementRef = elementRef;
            this.renderer = renderer;
        }
        /**
         * @return {?}
         */
        UiScrollComponent.prototype.ngOnInit = /**
         * @return {?}
         */
        function () {
            this.workflow = new Workflow(this);
        };
        /**
         * @return {?}
         */
        UiScrollComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.workflow.dispose();
        };
        UiScrollComponent.decorators = [
            { type: core.Component, args: [{
                        selector: '[ui-scroll]',
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        template: "<div data-padding-backward></div><div\n  *ngFor=\"let item of items\"\n  [attr.data-sid]=\"item.nodeId\"\n  [style.position]=\"item.invisible ? 'fixed' : null\"\n  [style.left]=\"item.invisible ? '-99999px' : null\"\n><ng-template\n  [ngTemplateOutlet]=\"template\"\n  [ngTemplateOutletContext]=\"{\n    $implicit: item.data,\n    index: item.$index\n }\"\n></ng-template></div><div data-padding-forward></div>"
                    }] }
        ];
        /** @nocollapse */
        UiScrollComponent.ctorParameters = function () { return [
            { type: core.ChangeDetectorRef },
            { type: core.ElementRef },
            { type: core.Renderer2 }
        ]; };
        return UiScrollComponent;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var version = '0.0.7';

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var UiScrollDirective = /** @class */ (function () {
        function UiScrollDirective(templateRef, viewContainer, resolver) {
            this.templateRef = templateRef;
            this.viewContainer = viewContainer;
            this.resolver = resolver;
        }
        Object.defineProperty(UiScrollDirective.prototype, "uiScrollOf", {
            set: /**
             * @param {?} datasource
             * @return {?}
             */
            function (datasource) {
                this.datasource = datasource;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @return {?}
         */
        UiScrollDirective.prototype.ngOnInit = /**
         * @return {?}
         */
        function () {
            var /** @type {?} */ templateView = this.templateRef.createEmbeddedView({});
            var /** @type {?} */ compFactory = this.resolver.resolveComponentFactory(UiScrollComponent);
            var /** @type {?} */ componentRef = this.viewContainer.createComponent(compFactory, undefined, this.viewContainer.injector, [templateView.rootNodes]);
            componentRef.instance.datasource = this.datasource;
            componentRef.instance.template = this.templateRef;
            componentRef.instance.version = version;
        };
        UiScrollDirective.decorators = [
            { type: core.Directive, args: [{ selector: '[uiScroll][uiScrollOf]' },] }
        ];
        /** @nocollapse */
        UiScrollDirective.ctorParameters = function () { return [
            { type: core.TemplateRef },
            { type: core.ViewContainerRef },
            { type: core.ComponentFactoryResolver }
        ]; };
        UiScrollDirective.propDecorators = {
            uiScrollOf: [{ type: core.Input }]
        };
        return UiScrollDirective;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var UiScrollModule = /** @class */ (function () {
        function UiScrollModule() {
        }
        UiScrollModule.decorators = [
            { type: core.NgModule, args: [{
                        declarations: [
                            UiScrollComponent,
                            UiScrollDirective
                        ],
                        imports: [common.CommonModule],
                        entryComponents: [UiScrollComponent],
                        exports: [UiScrollDirective],
                        providers: []
                    },] }
        ];
        return UiScrollModule;
    }());

    exports.UiScrollModule = UiScrollModule;
    exports.Datasource = Datasource;
    exports.ɵa = UiScrollComponent;
    exports.ɵb = UiScrollDirective;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=ngx-ui-scroll.umd.js.map
