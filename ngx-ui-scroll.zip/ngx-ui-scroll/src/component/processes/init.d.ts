import { Scroller } from '../scroller';
export default class Init {
    static run(scroller: Scroller, isScroll?: boolean): void;
}
