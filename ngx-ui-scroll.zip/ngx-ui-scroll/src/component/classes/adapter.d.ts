import { BehaviorSubject, Observable } from 'rxjs';
import { Adapter as IAdapter, ItemAdapter } from '../interfaces/index';
import { Scroller } from '../scroller';
export declare const generateMockAdapter: () => IAdapter;
export declare class Adapter implements IAdapter {
    readonly init: boolean;
    readonly init$: Observable<boolean>;
    readonly version: string | null;
    readonly isLoading: boolean;
    readonly isLoading$: BehaviorSubject<boolean>;
    readonly firstVisible: ItemAdapter;
    readonly firstVisible$: BehaviorSubject<ItemAdapter>;
    readonly lastVisible: ItemAdapter;
    readonly lastVisible$: BehaviorSubject<ItemAdapter>;
    readonly itemsCount: number;
    private isInitialized;
    private callWorkflow;
    private getVersion;
    private getIsLoading;
    private getIsLoading$;
    private getFirstVisible;
    private getFirstVisible$;
    private getLastVisible;
    private getLastVisible$;
    private getItemsCount;
    constructor();
    initialize(scroller: Scroller): void;
    reload(reloadIndex?: number | string): void;
}
