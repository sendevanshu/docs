import { BehaviorSubject } from 'rxjs';
import { Direction } from '../interfaces/index';
import { Cache } from './cache';
import { Item } from './item';
export declare class Index {
    forward: number | null;
    backward: number | null;
    constructor();
    reset(): void;
}
export declare class Buffer {
    private _items;
    $items: BehaviorSubject<any>;
    bof: boolean;
    eof: boolean;
    lastIndex: Index;
    cache: Cache;
    constructor();
    reset(reload?: boolean): void;
    items: Array<Item>;
    readonly size: number;
    setLastIndices(): void;
    getFirstVisibleItemIndex(): number;
    getLastVisibleItemIndex(): number;
    getEdgeVisibleItemIndex(direction: Direction, opposite?: boolean): number;
    getFirstVisibleItem(): Item | undefined;
    getLastVisibleItem(): Item | undefined;
    getEdgeVisibleItem(direction: Direction, opposite?: boolean): Item | undefined;
}
