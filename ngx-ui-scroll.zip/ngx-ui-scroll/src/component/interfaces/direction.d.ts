export declare enum Direction {
    forward = "forward",
    backward = "backward",
}
