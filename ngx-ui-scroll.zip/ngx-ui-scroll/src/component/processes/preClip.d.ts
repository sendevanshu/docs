import { Scroller } from '../scroller';
import { Direction } from '../interfaces/index';
export default class PreClip {
    static run(scroller: Scroller): void;
    static shouldClipByDirection(direction: Direction, scroller: Scroller): void;
}
